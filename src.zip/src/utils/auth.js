// utils/auth.js

// Call this function after a successful login
export function login(userData) {
  localStorage.setItem('user', JSON.stringify(userData));
}

// Call this function to remove user data on logout
export function logout() {
  localStorage.removeItem('user');
}

// Returns true if user is logged in
export function isLoggedIn() {
  return localStorage.getItem('user') !== null;
}

// Get user data if needed
export function getUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}
